from pkcs7 import PKCS7Encoder
from random import randbytes
from Crypto.Cipher import AES
import base64

def encrypt_val(clear_text):
    master_key = 'hahajulandukleinerlutscher'
    encoder = PKCS7Encoder()
    raw = encoder.encode(clear_text)
    iv = randbytes(16)
    cipher = AES.new( master_key, AES.MODE_CBC, iv, segment_size=128 )
    return base64.b64encode( iv + cipher.encrypt( raw ) ) 

print(encrypt_val("Sas"))